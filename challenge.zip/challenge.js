const solution = (sentence, wordsArr) => {
  /* your code here */
}

// test your solution
solution('dvvd  pddp', ['ddvv', 'dvcd', 'vvdd', 'pdpd'])
// ['ddvv', 'vvdd', 'pddp']

solution('laser space', ['lazing', 'lazy', 'lacer'])
// []
solution('We will eat tenderising meat at Rivera with no regally plate because there is none',
  ['administration', 'ingredients', 'admit', 'beat', 'arrive', 'blood', 'door', 'each', 'on', 'economic', 'gallery', 'edge', 'three', 'drop'])
// ['ingredients', 'arrive', 'on', 'gallery', 'three']
