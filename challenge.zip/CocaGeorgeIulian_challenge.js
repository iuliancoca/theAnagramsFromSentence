function isAnagram (str1, str2) {
    //Check if the two strings have different lengths
    if (str1.length !== str2.length) {
        return false;
    }
    if (str1 === str2)
    {
        return false;
    }
    
    var s1 = str1.split('').sort().join('');
    var s2 = str2.split('').sort().join('');
 
    return (s1 === s2);
}

const solution = (sentence, wordsArr) => {
  /* your code here */
  
   const solution = [];
   var wordsOfSentence = sentence.split(' ');

for (i=0; i < wordsOfSentence.length; i++)
 {
    for(j=0; j < words.length; j++)
    {
        var anagrams = isAnagram(wordsOfSentence[i].toLowerCase(), words[j].toLowerCase());
            if (anagrams == true)
                {
                    solution.push(words[j]);
                }
    }
 }
console.log(solution)
}
  
//  1) Adding by Coca George Iulian
words = ['ddvv', 'dvcd', 'vvdd', 'pdpd'];

// test your solution
solution('dvvd  pddp', ['ddvv', 'dvcd', 'vvdd', 'pdpd'])
// ['ddvv', 'vvdd', 'pddp']

//  2) Adding by Coca George Iulian
words = ['lazing', 'lazy', 'lacer']

solution('laser space', ['lazing', 'lazy', 'lacer'])
// []

//  3) Adding by Coca George Iulian
words = ['administration', 'ingredients', 'admit', 'beat', 'arrive', 'blood', 'door', 'each', 'on', 'economic', 'gallery', 'edge', 'three', 'drop']

solution('We will eat tenderising meat at Rivera with no regally plate because there is none',
  ['administration', 'ingredients', 'admit', 'beat', 'arrive', 'blood', 'door', 'each', 'on', 'economic', 'gallery', 'edge', 'three', 'drop'])
// ['ingredients', 'arrive', 'on', 'gallery', 'three']